import React from 'react';
import { motion } from 'framer-motion';
import {
    UserGroupIcon,
    KeyIcon,
    CogIcon,
    TruckIcon,
    CalendarIcon
} from '@heroicons/react/24/outline';

export function CarGrid() {
    const cars = [
        {
            id: 1747402476555,
            vehicleName: "GMC YUKON XL OR SIMILAR 2024",
            image: "https://res.cloudinary.com/dzonwo3nn/image/upload/v1747402439/pek6nsdpb4bwskilx7q2.jpg",
            numberOfSeats: "8",
            type: "suv",
            transmission: "automatic",
            createdAt: "2025-05-16T13:34:36.555Z"
        },
        {
            id: 1747402731357,
            vehicleName: "GMC YUKON SLE OR SIMILAR 2023",
            image: "https://res.cloudinary.com/dzonwo3nn/image/upload/v1747402692/j3rbuobycsoeh7jnc7z1.jpg",
            numberOfSeats: "5",
            type: "sedan",
            transmission: "automatic",
            createdAt: "2025-05-16T13:38:51.357Z"
        },
        {
            "image": "https://res.cloudinary.com/dzonwo3nn/image/upload/v1747508717/dqkxrbpvhiohzedsla92.jpg",
            "vehicleName": "MERCEDES - BENZ VITO TOURER 2023 OR SIMILAR",
            "numberOfSeats": "7",
            "type": "suv",
            "transmission": "automatic",
            "id": 1747508752134,
            "createdAt": "2025-05-17T19:05:52.135Z"
        },
        {
            id: 1747402876921,
            vehicleName: "TESLA MODEL Y DUAL MOTOR 2024 OR SIMILAR",
            image: "https://res.cloudinary.com/dzonwo3nn/image/upload/v1747402777/ujoubxqv08mxfmtu0ptd.jpg",
            numberOfSeats: "3",
            type: "compact-suv",
            transmission: "automatic",
            createdAt: "2025-05-16T13:41:16.921Z"
        }
    ];

    const getSpecs = (car) => [
        { icon: <UserGroupIcon className="w-5 h-5" />, text: `${car.numberOfSeats} Passengers` },
        { icon: <TruckIcon className="w-5 h-5" />, text: car.type.toUpperCase() },
        { icon: <CogIcon className="w-5 h-5" />, text: car.transmission.charAt(0).toUpperCase() + car.transmission.slice(1) },
        { icon: <CalendarIcon className="w-5 h-5" />, text: car.vehicleName.split(' ').pop() }
    ];

    const cardVariants = {
        hidden: {
            opacity: 0,
            y: 50,
            scale: 0.95
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 0.5,
                ease: "easeOut"
            }
        },
        hover: {
            scale: 1.02,
            y: -5,
            boxShadow: "0 0 20px rgba(255, 215, 0, 0.3)",
            transition: {
                duration: 0.2,
                ease: "easeInOut"
            }
        }
    };

    const imageVariants = {
        hover: {
            scale: 1.05,
            transition: {
                duration: 0.2,
                ease: "easeInOut"
            }
        }
    };

    const specVariants = {
        hidden: { opacity: 0, x: -20 },
        visible: i => ({
            opacity: 1,
            x: 0,
            transition: {
                delay: i * 0.1,
                duration: 0.3
            }
        })
    };

    return (
        <section className="py-8 bg-black">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.h2
                    initial={{ opacity: 0, y: -20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-3xl font-bold font-serif text-center mb-8 text-[#FFD700]"
                >
                    Our Premium Fleet
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cars.map((car) => (
                        <motion.div
                            key={car.id}
                            variants={cardVariants}
                            initial="hidden"
                            whileInView="visible"
                            whileHover="hover"
                            viewport={{ once: true, margin: "-100px" }}
                            className="bg-black rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-[#FFD700]/20 hover:border-[#FFD700] relative group"
                        >
                            <motion.div
                                className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                style={{
                                    background: 'linear-gradient(45deg, rgba(255, 215, 0, 0.1), rgba(255, 215, 0, 0.05))',
                                    border: '2px solid #FFD700',
                                    filter: 'blur(1px)',
                                    pointerEvents: 'none'
                                }}
                            />

                            <div className="p-6 relative z-10">
                                <motion.div
                                    initial={{ opacity: 0, y: -10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: 0.2 }}
                                    className="text-center mb-6"
                                >
                                    <h3 className="text-xl font-bold font-serif text-[#B8860B]">{car.vehicleName}</h3>
                                </motion.div>

                                <motion.div
                                    className="mb-6 overflow-hidden rounded-lg relative"
                                    whileHover="hover"
                                >
                                    <motion.div className="w-full h-full">
                                        <motion.img
                                            variants={imageVariants}
                                            src={car.image}
                                            alt={car.vehicleName}
                                            className="w-full h-[200px] md:h-[300px] object-contain md:object-cover object-center bg-black/40"
                                            loading="lazy"
                                        />
                                    </motion.div>
                                </motion.div>

                                <div className="grid grid-cols-2 gap-4">
                                    {getSpecs(car).map((spec, specIndex) => (
                                        <motion.div
                                            key={specIndex}
                                            custom={specIndex}
                                            variants={specVariants}
                                            initial="hidden"
                                            whileInView="visible"
                                            viewport={{ once: true }}
                                            className="flex items-center space-x-2 text-[#B8860B]/90 hover:text-[#FFD700] transition-colors duration-300"
                                        >
                                            <span className="text-[#B8860B] group-hover:text-[#FFD700] transition-colors duration-300">{spec.icon}</span>
                                            <span className="text-sm">{spec.text}</span>
                                        </motion.div>
                                    ))}
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
} 